These are the Alpha firmware version 0.72 files for the Byonics TinyTrak4 and MTT4B/MTT4BT

The file TT4_Alpha_v0.72_644.TT4 is for ATMEGA644P based TinyTrak4s with
bootloader version 1.2b, for kits or builts sold before July 2010.

The file TT4_Alpha_v0.72_1284.TT4 is for ATMEGA1284P based TinyTrak4s with
bootloader version 1.2c, for builts sold after June 2010.

The file MTT4B_Alpha_v0.72_1284.TT4 is for MTT4B/MTT4BT with ATMEGA1284P chips
and bootloader version 1.2c.

To load the firmware, follow the instructions in the TinyTrak4 Firmware Manual at
http://byonics.com/tinytrak4/TinyTrak4%20Firmware%20Manual%20v1.1.pdf

Please send comments to support @ byonics . com


Changes in v0.72
----------------------
Transceiver Squelch support
Fixed CDMODE Tones hang bug
Prevented PATH1 - and clearing MYCALL
Improved back to back (1 FLAG) decoding by increasing
  Audio Buffer size and optimizing serial output

Changes in v0.69/v0.70/v0.71
----------------------
Added PORTB support for Config menu
Added Transceiver Support (MTT4A fixed freq with Amp)
Added Transceiver Support (MTT4B TX/RX Freq)

Changes in v0.68
----------------------
Fixed Wind Speed Errors
Added DECSTAT to show incoming audio level and decoded TXD length for received packets.
Fixed MIC-E long decoding bug
Added support for AvMap weather reporting
Added DIGIMY setting to enable digipeating of MYCALL
Default AMODE & BMODE to GPS
Stopped digipeating unused WIDE2-0 (bugfix for KPC-3)
Send CR LF in GKRELAY
Added PASSTHRU command to help setting TT4BT settings

Changes in v0.67
----------------------
Fixed bug with GPS valid detection
Firmware manual and Config software do not require changes from v0.66

Changes in v0.66
----------------------
Added delay before considering gps valid
Made SOFTRST reset to bootloader
Made RXA, AMODE, etc take when entered by keyboard
Added MTXD and MPPER for PTT IN Support
Added LRNTPS to make TPS auto learning
Added GPSCHK to validate Checksum
Added INTCLK to force internal clock timing
Added GKRELAY to send GPS data to KISS port
Made C0 FF C0 work for SOFTRST in KISS


Changes in v0.65
----------------------
Added support for the ATMEGA1284P (1284) TinyTrak4


