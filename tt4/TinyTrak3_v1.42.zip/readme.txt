This .ZIP file contains the files needed to upgrade the firmware of a TinyTrak3Plus.  

Note only TinyTrak3Plus's with the 16F1827 chip can be upgraded this way.

Instructions for updating the TinyTrak3Plus firmware:
 - Obtain a copy of Tera Term Pro
 - Connect the TinyTrak3Plus the the computer serial port with a F-F null modem 
    cable or TT USB cable. This is the same cable used to update settings.
 - Start Tera Term Pro, and under Serial Port..., select the connected 
	COM port, 19200 baud, and a transmit delay of 1 msec/char
 - In the terminal program, press and hold the 'b' key
 - Apply power to the TinyTrap3Plus
 - The terminal should display "�_1" or "_1". If it doesn't, reset power
	to try again, keeping the 'b' key held.
 - Release the 'b' key
 - Press (and release) the 's' key.  Nothing will be changed in the terminal.
 - Choose File, Send File..., check the binary box, and select the 
	desired .t3f file containging the new firmware.
 - During the upload, nothing should be displayed on the terminal
 - After the upload was successful, the teminal should display a '*'. If
	it does not, repeat from the press and hold 'b' step. There 
	may be a few second delay after the Send File dialog closes
	and the '*' appears.
 - Quit Tera Term Pro
 - Cycle power on the TinyTrak3Plus
 - Run the TinyTrak3 config program to set the desired options.

Firmware v1.42 changes:
- Completed support for TT3 PCBs
- Improved packet timing to allow Kenwood D72A to decode better

Firmware v1.41 changes:
- Fixed bug when telemetry sequence reached 8281, it now wraps to 1023
- Turned off low power transmission during initial LED flashing
- Fixed bug where frequency not always set by increasing delay before freq setting.